﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class MCB : Bank
    {
        public override void issueCard()
        {
            Console.WriteLine("MCB Card is issued");
        }
        public override  int getInterestRate()
        {
            return 9;
        }
    }
}
