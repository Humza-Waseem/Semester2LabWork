﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {


            public static void Main(string[] args)
            {
            Bank b;
            b = new MCB();
            Console.WriteLine("MCB Rate of Interest is: " + b.getInterestRate() + "%");
            b.issueCard();
            Console.ReadKey();
            }
        
    }
}
