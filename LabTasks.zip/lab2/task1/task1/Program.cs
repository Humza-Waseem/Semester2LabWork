﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task1.BL;
namespace task1
{
    class Program
    {

        /* static void Main(string[] args)
         {
             //    ---------->>>>  first task   <<<<------------

             /* students s1 = new students();
              s1.name = "ahmad";
              s1.rollNo = 54;
              s1.cgpa = 3.25F;
              Console.WriteLine("Name : {0} RollNo: {1}  CGPA : {2}",s1.name,s1.rollNo,s1.cgpa);
             // Console.Read();

              students s2 = new students();
              s2.name = "bilal";
              s2.rollNo = 10;
              s2.cgpa = 3.75F;
              Console.WriteLine("Name : {0} RollNo: {1}  CGPA : {2}", s2.name, s2.rollNo, s2.cgpa);
              Console.Read();*/

        //    ---------->>>>  Second task   <<<<------------

        /*students s1 = new students();
        Console.WriteLine("enter the name of student:");
        s1.name = Console.ReadLine();
        Console.WriteLine("Enter the roll no :");
        s1.rollNo = Console.Read();
        Console.WriteLine("Enter the Cgpa :");
        s1.cgpa = float.Parse(Console.ReadLine());
        Console.WriteLine("Name : {0} RollNo: {1}  CGPA : {2}", s1.name, s1.rollNo, s1.cgpa);
        Console.ReadKey();*/


        //   ---------->>>>  third task   <<<<------------ 

        /*  students[] s = new students[10];
          char option;
          int count = 0;
          do
          {
              option = menu();
              if (option == '1')
              {
                  s[count] = addStudents();
                  count = count + 1;


              }
              else if (option == '2')
              {
                  viewStudent(s, count);
              }
              else if (option == '3')
              {
                  topStudent(s, count);
              }
              else if (option == '4')
              {
                  break;
              }
              else
              {
                  Console.WriteLine("Invald Choice");
              }
          }
          while (option != '4');

              Console.WriteLine("Press Enter to Exit...");
              Console.ReadKey();*/

        /*  products[] s = new products[10];
          char option;
          int count = 0;
          do
          {
              option = menu();
              if (option == '1')
              {
                  s[count] = addProducts();
                  count = count + 1;


              }
              else if (option == '2')
              {
                  viewProducts(s, count);
              }
              else if (option == '3')
              {
                  float tPrice = 0;

                  tPrice =totalPrice(s, count);
                  Console.WriteLine("The total worth of the store is :  {0}", tPrice);
                  Console.ReadLine();
              }
              else if (option == '4')
              {
                  break;
              }
              else
              {
                  Console.WriteLine("Invald Choice");

              }
          }
          while (option != '4');

          Console.WriteLine("Press Enter to Exit...");
          Console.ReadKey();


      }

      /*  static char menu()
        {
            Console.Clear();
            char choice;
            Console.WriteLine("Press 1 for adding a student: ");
            Console.WriteLine("Press 2 for view Student:  ");
            Console.WriteLine("Press 3  for Top THree students: ");
            Console.WriteLine("Press 4 to EXIT: ");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static students addStudents()
        {
            Console.Clear();
            students s1 = new students();
            Console.WriteLine("enter the name of student:");
            s1.name = Console.ReadLine();
            Console.WriteLine("Enter the roll no :");
            s1.rollNo = Console.Read();
            Console.WriteLine("Enter the Cgpa :");
            s1.cgpa = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Department: ");
            s1.department = Console.ReadLine();
            Console.WriteLine("Is Hostelide (y || n) :");
            s1.isHostelide = char.Parse(Console.ReadLine());
            return s1;
        }
        static void viewStudent(students[] s, int count)
        {
            Console.Clear();
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Name : {0}  \nRoll No : {1} \nCGPA : {2}  \nDepartment : {3} \nIsHolstelide : {4} ", s[i].name, s[i].rollNo, s[i].cgpa, s[i].department, s[i].isHostelide);
            }
            Console.WriteLine("Press any Key to COntinue...");
            Console.ReadKey();
        }
        static void topStudent(students[] s, int count)
        {
            Console.Clear();
            if (count == 0)
            {
                Console.WriteLine("No Record Present");

            }
            else if (count == 1)
            {
                viewStudent(s, 1);

            }
            else if (count == 2)
            {
                for (int x = 0; x < 2; x++)
                {
                    int i = largest(s, x, count);
                    students temp = s[i];
                    s[i] = s[x];
                    s[x] = temp;

                }
                viewStudent(s, 2);
            }
            else
            {
                for (int x = 0; x < 3; x++)
                {
                    int i = largest(s, x, count);
                    students temp = s[i];
                    s[i] = s[x];
                    s[x] = temp;
                }
                viewStudent(s, 3);
            }
        }
        static int largest(students[] s, int start, int end)
        {
            int i = start;
            float large = s[start].cgpa;
            for (int x = start; x < end; x++)
            {
                if (large < s[x].cgpa)
                {
                    large = s[x].cgpa;
                    i = x;

                }
            }
            return i;
        }


      static products addProducts()
      {
          Console.Clear();
          products s1 = new products();
          Console.WriteLine("enter the ID:");
          s1.ID = Console.ReadLine();
          Console.WriteLine("Enter  the NAME of product :");
          s1.name = Console.ReadLine();
          Console.WriteLine("Enter the PRICE of the :");
          s1.price = float.Parse(Console.ReadLine());
          Console.WriteLine("Enter the CATEGORY ");
          s1.Category = char.Parse(Console.ReadLine());
          Console.WriteLine("Is BRAND NAME :");
          s1.BrandName = Console.ReadLine();
          Console.WriteLine("Enter  THe COUNTRY ");
          s1.country = Console.ReadLine();
          return s1;
      }
      static void viewProducts(products[] s, int count)
      {
          Console.Clear();
          for (int i = 0; i < count; i++)
          {
              Console.WriteLine("ID : {0}  \nName : {1} \nCGPA : {2}  \nPRICE : {3} \nCategory : {4},\nBrand Name \nCountry\n\n", s[i].ID, s[i].name, s[i].price, s[i].Category, s[i].BrandName, s[i].country);
          }
          Console.WriteLine("Press any Key to COntinue...");
          Console.ReadKey();

      }
      static float totalPrice(products[] s, int count)
      {
          Console.Clear();
          float sum = 0;
          for (int i = 0; i < count; i++)
          {
              sum = sum + s[i].price;

          }
          Console.WriteLine("Total Price", sum);

          return sum;
      }
      static char menu()
      {
          Console.Clear();
          char choice;
          Console.WriteLine("Press 1 for Adding Products: ");
          Console.WriteLine("Press 2 to Show Products:  ");
          Console.WriteLine("Press 3 for displaying total worth of store: ");
          Console.WriteLine("Press 4 to EXIT: ");
          choice = char.Parse(Console.ReadLine());
          return choice;
      }
*/
        static void Main(string[] args)
        {
            char value = menu();
            do
            {
                if (value == 1)
                {
                    signUp();

                }
                if (value == 2)
                {
                    signIn();
                }
                if (value == 3)
                {
                    break;
                }
            }
            while (value != 4);
            Console.WriteLine("invalid input ...");
            Console.ReadLine();

            static char menu()
            {
                Console.Clear();
                char choice;
                Console.WriteLine(" 1.Sign UP");
                Console.WriteLine(" 2.Sign IN ");
                Console.WriteLine(" 3.EXIT");
                choice = char.Parse(Console.ReadLine());
                return choice;
            }
            static void signUp()
            {
                credentials s1 = new credentials();
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("**********Sign Up***********");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Enter your name:");
                s1.username = Console.ReadLine();
                Console.WriteLine("Enter your password:");
                s1.password = Console.ReadLine();
                Console.ReadKey();


            }
            static void signIn()
            {
                
            }
        }
    }
}
