﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EZInput;
namespace WindowsFormsApp1

{
    public partial class Form1 : Form
    {
        PictureBox enemyBlack;
        PictureBox enemyBlue;
        Random rand = new Random();
        string enemyBlackDirection = "MovingRight";
        string enemyBlueDirection = "MovingLeft";
        List<PictureBox> playerFires = new List<PictureBox>();
        List<PictureBox> enemyFires = new List<PictureBox>();

        bool isBlackLive = true;
        bool isBlueLive = true;

        public Form1()
        {
            InitializeComponent();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            MoveEnemy();
            if (Keyboard.IsKeyPressed(Key.RightArrow))
            {
                if (pbPlayerShip.Right < ClientSize.Width)
                {
                    pbPlayerShip.Left = pbPlayerShip.Left + 25;
                }
            }
            else if (Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                if (pbPlayerShip.Left > 0)
                {
                    pbPlayerShip.Left = pbPlayerShip.Left - 25;
                }
            }
            else if (Keyboard.IsKeyPressed(Key.UpArrow))
            {
                pbPlayerShip.Top = pbPlayerShip.Top - 25;
            }
            else if (Keyboard.IsKeyPressed(Key.DownArrow))
            {
                pbPlayerShip.Top = pbPlayerShip.Top + 25;
            }
            if (Keyboard.IsKeyPressed(Key.Space))
            {
                // For creatying FIres
                PictureBox pbFire = new PictureBox();
                Image fireImage = WindowsFormsApp1.Properties.Resources.Bullet11;
                pbFire.Image = fireImage;
                pbFire.SizeMode = PictureBoxSizeMode.Zoom;
                pbFire.Width = fireImage.Width - 30;
                pbFire.Height = fireImage.Height - 30;
                pbFire.BackColor = Color.Transparent;
                System.Drawing.Point fireLocation = new System.Drawing.Point();
                fireLocation.X = pbPlayerShip.Left + 25;
                fireLocation.Y = pbPlayerShip.Top - 15;
                pbFire.Location = fireLocation;
                playerFires.Add(pbFire);
                this.Controls.Add(pbFire);


            }
            foreach (PictureBox bullet in playerFires)
            {
                bullet.Top = bullet.Top - 20;
            }
            for (int idx = 0; idx < playerFires.Count; idx++)
            {
                if (playerFires[idx].Bottom < 0)
                {
                    playerFires.Remove(playerFires[idx]);
                }
            }
            foreach (PictureBox bullets in playerFires)
            {
                if(bullets.Bounds.IntersectsWith(enemyBlack.Bounds))
                {
                    enemyBlack.Hide();
                    isBlackLive = false;
                }
                if (bullets.Bounds.IntersectsWith(enemyBlue.Bounds))
                {
                    enemyBlue.Hide();
                    isBlueLive = false;
                }

                if(isBlackLive == false && isBlueLive == false)
                {
                    timer1.Enabled = false;
                    MessageBox.Show("Mubarik ho ap game jeet gye ho");
                    this.Close();
                }
                foreach(PictureBox bulletes in enemyFires)
                {
                    if(bulletes.Bounds.IntersectsWith(pbPlayerShip.Bounds))
                    {
                        if(pbPlayerHealth.Value > 0)
                        {
                            pbPlayerHealth.Value = pbPlayerHealth.Value - 10;
                        }
                    }
                }
/*
                if(enemyBlueLastTimeToFire >= enemyBlueTimeToFire)
                {
                    Image fireImage = WindowsFormsApp1.Properties.Resources.FireEnemy;
                    PictureBox pbFire = creatFire(fireImage, enemyBlue);
                    enemyFires.Add(pbFire);
                    this.Controls.Add(pbFire);
                    enemyBlueLastTimeToFire = 0;
                }
                if (enemyBlackLastTimeToFire >= enemyBlackimeToFire)
                {
                    Image fireImage = WindowsFormsApp1.Properties.Resources.FireEnemy;
                    PictureBox pbFire = creatFire(fireImage, enemyBlue);
                    enemyFires.Add(pbFire);
                    this.Controls.Add(pbFire);
                    enemyBlackLastTimeToFire = 0;
                }


                /*  foreach(PictureBox bullet in playerFires)
                   {
                       bool removeBullet = false;
                       foreach(PictureBox pbMeteor in meteorsList)
                       {

                       }
                   }*/
            }
        }
        private PictureBox createFire(Image fireImage,PictureBox source)
        {
            PictureBox pbFire = new PictureBox();
            pbFire.Image = fireImage;
            pbFire.Width = fireImage.Width;
            pbFire.Height = fireImage.Height;
            pbFire.BackColor = Color.Transparent;
            System.Drawing.Point fireLocation = new System.Drawing.Point();
            fireLocation.X = source.Left + (source.Width / 2) - 5;
            fireLocation.Y = source.Top;
            pbFire.Location = fireLocation;
            pbFire.Location = fireLocation;
            return pbFire;

            
        }

        private PictureBox createEnemy(Image img)
        {
            PictureBox pbEnemy = new PictureBox();
            int left = rand.Next(30, this.Width);
            int top = rand.Next(5, img.Height + 20);
            pbEnemy.Left = left;
            pbEnemy.Top = top;
            pbEnemy.SizeMode = PictureBoxSizeMode.Zoom;
            pbEnemy.Width = img.Width - 100;
            pbEnemy.Height = img.Height - 100;
            pbEnemy.BackColor = Color.Transparent;
            pbEnemy.Image = img;
            return pbEnemy;
        }
        private void createPlayer()
        {
            // \\\\\\  for Creating a player at runtime  ////
            pbPlayerShip = new PictureBox();
            Image imgPlayer = WindowsFormsApp1.Properties.Resources.HeroShip;
            pbPlayerShip.Height = imgPlayer.Height - 100;
            pbPlayerShip.Width = imgPlayer.Width - 100;
            pbPlayerShip.SizeMode = PictureBoxSizeMode.Zoom;

            pbPlayerShip.Top = this.Height - (imgPlayer.Height + 60);
            pbPlayerShip.Image = imgPlayer;
            pbPlayerShip.BackColor = Color.Transparent;

            pbPlayerHealth = new ProgressBar();
            pbPlayerHealth.Value = 80;
            pbPlayerHealth.Step = 10;
            pbPlayerHealth.Height = 10;
            pbPlayerHealth.Width = 80;
            pbPlayerHealth.Left = pbPlayerShip.Left;
            pbPlayerHealth.Top = pbPlayerShip.Bottom + 4;

            this.Controls.Add(pbPlayerShip);
            this.Controls.Add(pbPlayerHealth);



        }
        private void MoveEnemy()
        {
            int x, y;
            if(enemyBlack.Top >= 500)
            {
                x = rand.Next(0, 300);
                enemyBlack.Location = new System.Drawing.Point(x, 0);
            }
            if(enemyBlue.Top >=500)
            {
                y = rand.Next(0, 300);
                enemyBlue.Location = new System.Drawing.Point(y, 0);
                 
            }
            else
            {
                enemyBlue.Top += 15;
                enemyBlack.Top += 10;
            }
        }

        private void moveEnemy(PictureBox enemy, ref string enemyDirection)
        {
            
            if (enemyDirection == "MovingRight")
            {
                enemy.Left = enemy.Left + 10;
            }
            if (enemyDirection == "MovingLeft")
            {
                enemy.Left = enemy.Left - 10;
            }
            if ((enemy.Left + enemy.Width) > this.Width)
            {
                enemyDirection = "MovingLeft";
            }
            if (enemy.Left <= 2)
            {
                enemyDirection = "MovingRight";
            }
        }
      
    

        private void Form1_Load_1(object sender, EventArgs e)
        {
            createPlayer();
            enemyBlack = createEnemy(WindowsFormsApp1.Properties.Resources.EnemyRed);
            enemyBlue = createEnemy(WindowsFormsApp1.Properties.Resources.EnemyGreen);

            moveEnemy(enemyBlack, ref enemyBlackDirection);
            moveEnemy(enemyBlue, ref enemyBlueDirection);


            this.Controls.Add(enemyBlack);
            this.Controls.Add(enemyBlue);

        }

        private void ProgressBarOfHero_Click(object sender, EventArgs e)
        {

        }
    }
}
