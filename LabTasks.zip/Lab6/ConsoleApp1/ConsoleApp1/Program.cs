﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using ConsoleApp1.DL;
using ConsoleApp1.UI;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //((((((((--------------PAths Of Files-------------)))))))))
            string subjectPath = "E:\\OOPlab\\Lab6\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\subject.txt";
            string degreePath = "E:\\OOPlab\\Lab6\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\degree.txt";
            string studentPath = "E:\\OOPlab\\Lab6\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\student.txt";

            if (SubjectDL.readFromFile(subjectPath))
            {
                Console.WriteLine("Subject Data Loaded SUccessfully");

            }
            if (DegreeProgramDL.readFromFile(degreePath))
            {
                Console.WriteLine("Degree program Data Loaded Successfully");

            }
            if (StudentDL.readFromFile(studentPath))
            {
                Console.WriteLine("Student Data loaded Sucessfully ");

            }
            int option;
            do
            {
                option = MenuUI.Menu();
                MenuUI.clearScreen();
                if (option == 1)
                {
                    if (DegreeProgramDL.programList.Count > 0)
                    {
                        Student s = StudentUI.takeInputForStudent();
                        StudentDL.addIntoStudentList(s);
                        StudentDL.storeIntoFile(studentPath, s);

                    }
                }
                else if (option == 2)
                {
                    DegreeProgram d = DegreeProgramUI.takeInputForDegree();
                    DegreeProgramDL.addIntoDegreeList(d);
                    DegreeProgramDL.storeIntoFile(degreePath, d);
                }
                else if (option == 3)
                {
                    List<Student> sortedStudentList = new List<Student>();
                    sortedStudentList = StudentDL.sortStudentsByMerit();
                    StudentDL.giveAdmission(sortedStudentList);
                    StudentUI.printStudents();

                }
                else if(option == 4)
                {
                    StudentUI.viewRegisteredStudents();

                }
                else if(option == 5)
                {
                    string degName;
                    Console.WriteLine("Enter Degree Name : ");
                    degName = Console.ReadLine();
                    StudentUI.viewStudentInDegree(degName);


                }
                else if(option == 6)
                {
                    Console.WriteLine("enter student name : ");
                    string name = Console.ReadLine();
                    Student s = StudentDL.StudentPresent(name);
                    if(s !=null)
                    {
                        SubjectUI.viewSubjects(s);
                        SubjectUI.registerSubjects(s);
                    }
                }
                else if(option == 7)
                {
                    StudentUI.calcualteFeeForAll();
                }
                MenuUI.clearScreen();

            }
            while (option != 8);



        }



    }
}
