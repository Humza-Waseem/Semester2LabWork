﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ConsoleApp1.BL;

namespace ConsoleApp1.UI
{
    class SubjectUI
    {
        public static Subject takeInputForSubject()
        {
            string code;
            string type;
            int creditHours;
            int subjectFees;
            Console.WriteLine("Enter the subject CODE: ");
            code = Console.ReadLine();
            Console.WriteLine("Enter the Subject Type : ");
            type = Console.ReadLine();
            Console.WriteLine("Enter Subject Credit Hours : ");
            creditHours = int.Parse(Console.ReadLine());
            Console.WriteLine("ENtre the Subject Fees :");
            subjectFees = int.Parse(Console.ReadLine());

            Subject sub = new Subject(code, type, creditHours, subjectFees);
            return sub;
        }
        public static void viewSubjects(Student s)
        {
            if(s.regDegree != null)
            {
                Console.WriteLine("Sub COde\tSub TYpe");
                foreach(Subject sub in s.regDegree.subjects)
                {
                    Console.WriteLine(sub.code + "\t\t" + sub.type);

                }
            }
        }
        public static void registerSubjects(Student s)
        {
            Console.WriteLine("Enter how many subjects you want to register : ");
            int count = int.Parse(Console.ReadLine());
            for(int x = 0; x< count; x++)
            {
                Console.WriteLine("Enter the Subject Code ");
                string code = Console.ReadLine();
                bool flag = false;
                foreach ( Subject sub in s.regDegree.subjects)
                {
                    if(s.regStudentSubject(sub))
                    {
                        flag = true;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("A student cannot have more than 9 CH");
                        flag = true;
                        break;
                    }
                }
                if(flag == false)
                {
                    Console.WriteLine("Enter Valis COurse");
                    x--;
      
                }
            }

        }

    }
}
