﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using ConsoleApp1.DL;

namespace ConsoleApp1.UI
{
    class StudentUI
    {
        public static void printStudents()
        {
            foreach(Student s in StudentDL.studentList)
            {
                if(s.regDegree !=null)
                {
                    Console.WriteLine(s.name + "got Admission in" + s.regDegree.degreeName);

                }
                else
                {
                    Console.WriteLine(s.name + "did not get Admission ");

                }
            }
        }
        public static void viewStudentInDegree(string degName)
        {
            Console.WriteLine("Name\tFSC\tEcat\tAge");
            foreach(Student s in StudentDL.studentList)
            {
                if(s.regDegree != null)
                {
                    if(degName == s.regDegree.degreeName)
                    {
                        Console.WriteLine(s.name + "\t" + s.fscMarks + "\t" + s.ecatMarks + "\t" + s.age);

                    }
                }
            }
        }
        public static void viewRegisteredStudents()
        {
            Console.WriteLine("Name\tFSC\tEcat\tAge");
            foreach (Student s in StudentDL.studentList)
            {
                if (s.regDegree != null)
                {
                    Console.WriteLine(s.name + "\t" + s.fscMarks + "\t" + s.ecatMarks + s.age);

                }
            }
        }
        public static Student takeInputForStudent()
        {
            string name;
            int age;
            double fscMarks;
            double ecatMarks;
            List<DegreeProgram> preferences = new List<DegreeProgram>();
            Console.WriteLine("Enter the student Name : ");
            name = Console.ReadLine();
            Console.WriteLine("ENter the student age : ");
            age = int.Parse(Console.ReadLine());
            Console.Write("Enter student FSC marks : ");
            fscMarks = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter student ecat marks : ");
            ecatMarks = double.Parse(Console.ReadLine());
            Console.WriteLine("enter Available Degree PRograms ");
            DegreeProgramUI.viewDegreePrograms();

            Console.Write("Enter how many preferences to enter : ");
            int count = int.Parse(Console.ReadLine());
            for (int x = 0; x< count; x++) 
            {
                string degName = Console.ReadLine();
                bool flag = false;
                foreach (DegreeProgram dp in DegreeProgramDL.programList)
                {
                    if (degName == dp.degreeName && !(preferences.Contains(dp)))
                    {
                        preferences.Add(dp);
                        flag = true;
                    }
                }
                if (flag == false)
                {
                    Console.WriteLine("Enter Valid Degree program Name : ");
                    x--;
                }
            }
            Student s = new Student(name, age, fscMarks, ecatMarks, preferences);
            return s; 

        }
        public static void calcualteFeeForAll()
        {
            foreach(Student s in StudentDL.studentList)
            {
                if(s.regDegree != null)
                {
                    Console.WriteLine(s.name + "has " + s.calculateFee() + " fees ");

                }

            }
        }
    }
}
