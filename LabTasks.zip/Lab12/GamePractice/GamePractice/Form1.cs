﻿using EZInput;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GamePractice
{ 
    public partial class GamingForm : Form
    {
        PictureBox enemyBlack;
        PictureBox enemyBlue;
        Random rand = new Random();
        string enemyBlackDirection = "left";
        string enemyBlueDirection = "left";
        List<PictureBox> playerFires = new List<PictureBox>();
        public GamingForm()
        {
            InitializeComponent();
        }
        private void TimerGameLoop_Tick(object sender, EventArgs e)
        {
            if (Keyboard.IsKeyPressed(Key.RightArrow))
            {
                if (pbPlayerShip.Right < ClientSize.Width)
                {
                    pbPlayerShip.Left = pbPlayerShip.Left + 25;
                }
            }
            else if (Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                if (pbPlayerShip.Left > 0)
                {
                    pbPlayerShip.Left = pbPlayerShip.Left - 25;
                }
            }
            else if (Keyboard.IsKeyPressed(Key.UpArrow))
            {
                pbPlayerShip.Top = pbPlayerShip.Top - 25;
            }
            else if (Keyboard.IsKeyPressed(Key.DownArrow))
            {
                pbPlayerShip.Top = pbPlayerShip.Top + 25;
            }
            if (Keyboard.IsKeyPressed(Key.Space))
            {
                Image fireImage = GamePractice.Properties.Resources.fireImage;
                PictureBox pbFire = createFire(fireImage, pbPlayerShip);
                playerFires.Add(pbFire);
                this.Controls.Add(pbFire);
            }
            foreach (PictureBox bullet in playerFires)
            {
                bullet.Top = bullet.Top - 20;
            }
            for(int idx = 0; idx < playerFires.Count; idx++)
            {
                if (playerFires[idx].Bottom < 0) 
                {
                    playerFires.Remove(playerFires[idx]);
                }
            }
        }

        private PictureBox createEnemy(Image img)
        {
            PictureBox pbEnemy = new PictureBox();
            int left = rand.Next(30, this.Width);
            int top = rand.Next(5, img.Height + 20);
            pbEnemy.Left = left;
            pbEnemy.Top = top;
            pbEnemy.Height = img.Height - 250;
            pbEnemy.BackColor = Color.Transparent;
            pbEnemy.Image = img;
            return pbEnemy;
        }

        private void moveEnemy(PictureBox enemy, ref string enemyDirection)
        {
            if(enemyDirection == "MovingRight")
            {
                enemy.Left = enemy.Left + 10;
            }
            if (enemyDirection == "MovingLeft")
            {
                enemy.Left = enemy.Left - 10;
            }
            if ((enemy.Left + enemy.Width) > this.Width)
            {
                enemyDirection = "MovingLeft";
            }
            if (enemy.Left <= 2)
            {
                enemyDirection = "MovingRight";
            }
        }
        private void GamingForm_Load(object sender, EventArgs e)
        {
            enemyBlack = createEnemy(GamePractice.Properties.Resources.enemy);
            enemyBlue = createEnemy(GamePractice.Properties.Resources.enemy);
            this.Controls.Add(enemyBlack);
            this.Controls.Add(enemyBlue);
            moveEnemy(enemyBlack, ref enemyBlackDirection);
            moveEnemy(enemyBlue, ref enemyBlueDirection);
        }
        private PictureBox createFire(Image fireImage, PictureBox source)
        {
            PictureBox pbFire = new PictueBox();
            pbFire.Image = fireImage;
            pbFire.SizeMode = PictureBoxSizeMode.Zoom;
            pbFire.Width = fireImage.Width -150;
            pbFire.Height = fireImage.Height - 150;
            pbFire.BackColor = Color.Transparent;
            System.Drawing.Point fireLocation = new System.Drawing.Point();
       //     fireLocation = new System.Drawing.Point();
          //  fireLocation.X = source.Left + (source.Width / 2) - 5;
           // fireLocation.Y = source.Top;
           fireLocation.X = pbPlayerShip.Left + 25;
            fireLocation.Y = pbPlayerShip.Top - 15;
            pbFire.Location = fireLocation;
            return pbFire;
        }
    }
}