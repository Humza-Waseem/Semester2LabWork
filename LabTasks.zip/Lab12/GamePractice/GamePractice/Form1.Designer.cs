﻿
namespace GamePractice
{
    partial class GamingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Timer TimerGameLoop;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GamingForm));
            this.pbPlayerShip = new System.Windows.Forms.PictureBox();
            TimerGameLoop = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayerShip)).BeginInit();
            this.SuspendLayout();
            // 
            // TimerGameLoop
            // 
            TimerGameLoop.Enabled = true;
            TimerGameLoop.Tick += new System.EventHandler(this.TimerGameLoop_Tick);
            // 
            // pbPlayerShip
            // 
            this.pbPlayerShip.BackColor = System.Drawing.Color.Transparent;
            this.pbPlayerShip.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPlayerShip.BackgroundImage")));
            this.pbPlayerShip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPlayerShip.Location = new System.Drawing.Point(319, 294);
            this.pbPlayerShip.Name = "pbPlayerShip";
            this.pbPlayerShip.Size = new System.Drawing.Size(53, 50);
            this.pbPlayerShip.TabIndex = 0;
            this.pbPlayerShip.TabStop = false;
            // 
            // GamingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(908, 497);
            this.Controls.Add(this.pbPlayerShip);
            this.Name = "GamingForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.GamingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayerShip)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPlayerShip;
    }
}

