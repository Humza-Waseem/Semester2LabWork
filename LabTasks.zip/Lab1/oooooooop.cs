﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1
{
    class Program
    {
        static void Main(string[] args)
        {
            //func1();
            //func2();
            //func3();
            //func4();
            //func5();
            //func6();
            //func7();
            //func8();
            //func9();
            //func10();
            //func11();
            //func12();
            //unc13();\
            //func14();
            //func15();
            //func16();
            func17();


        }
        public static void func1()
        {
            Console.Write("Hello world");
            Console.Write("Hello world");
            Console.Read();

        }
        public static void func2()
        {
            Console.WriteLine("Hello world");
            Console.Write("Hello world");
            Console.Read();

        }
        public static void func3()
        {
            int var = 7;
            Console.WriteLine("Value: ");
            Console.Write(var);
            Console.ReadKey();

        }
        public static void func4()
        {
            string var = "I m string";
            Console.WriteLine("String: ");
            Console.Write(var);
            Console.ReadKey();
        }
        public static void func5()
        {
            char var = 'A';
            Console.WriteLine("Character: ");
            Console.Write(var);
            Console.ReadKey();

        }
        public static void func6()
        {
            float var = 2.2F;
            Console.WriteLine("Decimal: ");
            Console.Write(var);
            Console.ReadKey();

        }
        public static void func7()
        {
            string str;
            str = Console.ReadLine();
            Console.WriteLine("you have inputted: ");
            Console.WriteLine(str);
            Console.ReadKey();
        }
        public static void func8()
        {
            string str;
            str = Console.ReadLine();
            Console.WriteLine("You have inputted: ");
            int num = int.Parse(str);
            Console.WriteLine("The number is :");
            Console.Write(num);
            Console.ReadLine();

        }
        public static void func9()
        {
            string str;
            Console.WriteLine("Enter floating Point value: ");
            str = Console.ReadLine();
            float num = float.Parse(str);
            Console.WriteLine("The floating value is = ");
            Console.Write(num);
            Console.ReadKey();

        }
        public static void func10()
        {
            float length;
            float area;
            string str;
            Console.WriteLine("Enter the length: ");
            str = Console.ReadLine();
            length = float.Parse(str);
            area = length * length;
            Console.WriteLine("the area is : ");
            Console.Write(area);
            Console.ReadKey();
        }
        public static void func11()
        {
            string input;
            float marks;
            Console.Write("Enter the marks: ");
            input = Console.ReadLine();
            marks = float.Parse(input);
            if (marks > 50)
            {
                Console.WriteLine("You are Passed");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("You are Failed");
                Console.ReadKey();
            }


        }
        public static void func12()
        {
            for (int x = 0; x < 5; x++)
            {
                Console.WriteLine("Welcome jack");
            }
            Console.Read();
        }
        public static void func13()
        {
            int num;
            int sum = 0;
            Console.Write("Enter the  number:");
            num = int.Parse(Console.ReadLine());
            while (num != -1)

            {
                sum = sum + num;
                Console.Write("Enter NUmber:");
                num = int.Parse(Console.ReadLine());


            }
            Console.WriteLine("total sumis {0}", sum);
            Console.Read();
        }
        public static void func14()
        {
            int num;
            int sum = 0;
            do
            {
                Console.Write("Enter number: ");
                num = int.Parse(Console.ReadLine());
                sum = sum + num;


            }
            while (num != -1);
            sum = sum + 1;
            Console.WriteLine("The total sum is {0}", sum);
            Console.Read();
        }
        public static void func15()
        {

            int[] numbers = new int[3];
            for (int i = 0; i < 3; i++)
            {
                Console.Write("Enter the number{0}: ", i);
                numbers[i] = int.Parse(Console.ReadLine());
            }

            //Finding the largest
            int largest = -1;
            for (int i = 0; i < 3; i++)
            {
                if (numbers[i] > largest)
                {
                    largest = numbers[i];
                }
            }

            Console.WriteLine("Largest is : {0}", largest);
            Console.Read();
        }

        //file handling
        public static void func17()
        {
            int num1;
            int num2;
            Console.Write("Enter 1st Number: ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("Enter 2nd Number: ");
            num2 = int.Parse(Console.ReadLine());
            int result = add(num1, num2);
            Console.WriteLine("Sum is {0}", result);
            Console.Read();


        }
        public static int add (int n1, int n2)

        {
            return n1 + n2;
        }
        public static void func18()
        {
            string path =
                if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)

                {
                    Console.WriteLine(record);

                }
                fileVariable.Close();
            }
            else
            {
                Console.WriteLine("NOt exists");

            } }


        }

    }

