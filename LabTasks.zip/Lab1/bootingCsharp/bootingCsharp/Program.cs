﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bootingCsharp
{
    class Program
    {
        static void Main(string[] args)
        {

            Lily();
          /*  int[] num = new int[3];
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("enter the elements of array:");
                num[i] = int.Parse(Console.ReadLine());
            }
            int largest = 0;
            for (int i = 0; i < 3; i++)
            {
                if (num[i] > largest)
                {
                    largest = num[i];

                }

            }

            Console.WriteLine("largest value is : {0}", largest);
            Console.ReadKey();*/

        }
        static void Lily()
        {
            int lilyAge;

            Console.WriteLine("Enter lily's Age :");
            lilyAge = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.White;


            int priceMachine;
            Console.WriteLine("Enter the Price of Machine:");
            priceMachine = int.Parse(Console.ReadLine());
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.ForegroundColor = ConsoleColor.Red;

            int totalMoney = 0;
            int toysPrice;

            Console.WriteLine("Enter the Price of the Toys of Lily: ");
            toysPrice = int.Parse(Console.ReadLine());
            Console.BackgroundColor = ConsoleColor.Yellow;
            int evenBirthdays = 0;
            int oddBirthdays = 0; ; ; ; ; ;
            int brothersCutting = 0;
            int j = 1;
            for (int i = 2; i <= lilyAge; i = i + 2)
            {
                
                   evenBirthdays = evenBirthdays + (10*j);
                    brothersCutting = brothersCutting + 1;
                j++;
            }
            for (int i = 1; i <= lilyAge; i = i + 2)
            {
                    oddBirthdays = oddBirthdays + toysPrice;
            } 
       
           
            int finalMoney = 0;
            totalMoney = ((evenBirthdays- brothersCutting) + oddBirthdays);
            finalMoney = totalMoney - priceMachine;

            if(totalMoney<priceMachine)
            {
                Console.WriteLine("No!!");
                Console.Write("She Needs: {0}$" ,finalMoney);
            }
            else if(totalMoney > priceMachine)
            {
                Console.WriteLine("Yes");
                Console.Write("She has :{0}$" , finalMoney);

            }

            Console.ReadKey();

        }

    }
}
