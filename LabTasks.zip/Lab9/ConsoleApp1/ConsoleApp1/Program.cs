﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.UI;
using ConsoleApp1.BL;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();

            Animal d = new Dog("BaraHamza");
            Animal d1 = new Dog("Tommy");

            Animal c = new Cat("kitta");
            Animal c1 = new Cat("billa");
            
            foreach(Animal a in animals)
            {
                animals.Add(a);
               
            }
            foreach (Animal a in animals)
            {
                a.greets();
                a.toString();
            }
          /*      c.greets();
            c.toString();
            c1.greets();
            c1.toString();
            d.greets();
            d.greets();
            d1.greets();
            d1.toString();*/
           


            Console.ReadKey();



        }
        static string printHeader()
        {
            string name;
            Console.WriteLine("Enter the Name of Dog : ");
            name = Console.ReadLine();
            return name;
        }
        static string getCatName()
        {
            string name;
            Console.WriteLine("Enter the Name of Cat : ");
            name = Console.ReadLine();
            return name;
        }
    }
}
