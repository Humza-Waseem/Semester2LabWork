﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL
{
    class Dog : Mammal
    {
        public Dog(string name) :base(name)
        {
            this.name = name;
        }
        public  override void greets()
        {
            Console.WriteLine("Woof");
        }
        public override string  toString()
        {
            return name + " ";
        }
        public string  setDogName(string name)
        {
            if(name == "null")
            {
                return null;

            }
            else
            {
                name = "kutta";
                return name;
            }

        }
    }
}
