﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL
{
    class Mammal : Animal
    {
        public Mammal(string name) : base(name)
        {
            this.name = name;
        }
        public virtual string toString()
        {
            return name + " ";
        }
        public virtual void greets()
        {

        }
    }
}
