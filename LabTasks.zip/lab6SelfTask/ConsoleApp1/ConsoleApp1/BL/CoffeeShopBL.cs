﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class CoffeeShop
    {

        public string shopName;
        public static List<MenuItem> items = new List<MenuItem>();

        public static List<string> listOfOrders = new List<string>();

        public CoffeeShop(string shopName)
        {
            this.shopName = shopName;

        }
       /* public CoffeeShop(string itemName , string type, float price)
        {
            
            
        }*/
       

            public CoffeeShop addMenuItem(List<MenuItem> items)
            {
             
             return null;
            }
    }
}
