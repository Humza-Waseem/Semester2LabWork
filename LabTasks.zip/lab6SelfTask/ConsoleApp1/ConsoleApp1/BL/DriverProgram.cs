﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.UI;
using ConsoleApp1.DL;


namespace ConsoleApp1
{
    class Program
    {

        static void Main(string[] args)
        {
            List<MenuItem> items = new List<MenuItem>();
            while (true)
            {
                
                //  string name = "Hamza";
                // CoffeeShopDL c = new CoffeeShopDL(name);

                CoffeeShopDL.addOrdersToList(items);
                
            }
           
            Console.ReadKey();

        }
    }
}
