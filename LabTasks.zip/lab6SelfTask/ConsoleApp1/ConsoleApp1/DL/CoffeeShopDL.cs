﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.UI;
using ConsoleApp1.DL;


namespace ConsoleApp1.DL
{
    class CoffeeShopDL

        
    {
       // public static List<MenuItem> items = new List<MenuItem>();

      //  public static List<string> listOfOrders = new List<string>();
        public static  CoffeeShop addOrdersToList(List<MenuItem> items)
        {

            Console.WriteLine("Enter the name of item :");
            string itemName = Console.ReadLine();
            Console.WriteLine("Enter the type of item : ");
            string type = Console.ReadLine();
            Console.WriteLine("enter the Price : ");
            float price = float.Parse(Console.ReadLine());

            MenuItem s = new MenuItem(itemName, type, price);
            CoffeeShopUI.addMenuItemsToList(items,s);
            CoffeeShopUI.printList(items, s);
            return null;


        }

    }
}
