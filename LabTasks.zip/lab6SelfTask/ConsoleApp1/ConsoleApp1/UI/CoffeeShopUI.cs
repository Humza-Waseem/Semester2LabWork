﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.DL;
using ConsoleApp1.UI;

namespace ConsoleApp1.UI
{
    class CoffeeShopUI
    {
        public static List<string> listOfOrders = new List<string>();
        public static void addMenuItemsToList(List<MenuItem> items,MenuItem s)
        {
            items.Add(s);
        }
        public static void printList(List<MenuItem> items, MenuItem s)
        {
            foreach(MenuItem m in items)
            {
                Console.WriteLine("The name : " + s.name);
                Console.WriteLine("Type : " + s.type);
                Console.WriteLine("price : " + s.price);

            }
        }

    }
}
