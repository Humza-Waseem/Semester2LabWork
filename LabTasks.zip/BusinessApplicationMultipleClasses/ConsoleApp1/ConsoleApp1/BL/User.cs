﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL
{
    internal class mUser
    {
        public string name;
        public string password;
        public string role;
       
        public mUser(string name, string password)
        {
            this.name = name;
            this.password = password;

        }
        public mUser(string name, string password, string role)
        {
            this.name = name;
            this.password = password;
            this.role = role;


        }
        public bool isAdmin()
        {
            if (role == "admin" || role == "ADMIN" || role == "Admin")

            {
                return true;

            }
            return false;
        }
        public bool isCostumer()
        {
            if(role == "costumer" || role =="Costumer" || role == "COSTUMER")
            {
                return true;
            }
            return false;
        }

    }
}

