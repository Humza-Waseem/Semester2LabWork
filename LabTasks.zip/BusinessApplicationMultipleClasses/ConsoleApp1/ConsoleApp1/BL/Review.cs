﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL
{
    class Review
    {
        public string carForReview;
        public int stars;
        
        public Review(string carForReview,int stars)
        {
            this.carForReview = carForReview;
            this.stars = stars;
        }
        public Review printReviews(List<Review> reviews,Review r)
        {
            int i = 0;
            foreach(Review s in reviews)
            {
                Console.WriteLine("THe Stars :{0}\t For :{1} ", reviews[i].stars, reviews[i].carForReview);
                i++;
                
            }
           
            return r;
        }

    }


    
}
