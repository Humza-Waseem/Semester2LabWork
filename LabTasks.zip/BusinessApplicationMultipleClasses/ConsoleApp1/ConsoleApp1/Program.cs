﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using System.IO;
using System.ComponentModel.Design;
using System.Security.Cryptography.X509Certificates;
using ConsoleApp1.BL.BL;

namespace ConsoleApp1
{
    internal class Program
    {


        static void Main(string[] args)
        {
            //  >>>>  List of name USERS  and DataType User that is a class 
            List<mUser> users = new List<mUser>();

            //   >>>>>>   List of CARS 
            List<mCar> cars = new List<mCar>();

            // file for user Data
            string path = "textfile.txt";

            // file for CAR DATA
            string path2 = "E:\\OOPlab\\BusinessApplicationMultipleClasses\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\cars.txt";



            int option;
            readData(path, users);
            readCarData(path2, cars);
            //reading the file in which our data is saved
            /*    bool check = readData(path, users);

                //fuction to read Car DATA B4 fuction exection
                readCarData(path2, cars);


                if (check)
                {
                    Console.WriteLine("Data Loaded Successfully");

                }
                else
                Console.WriteLine("Data not Loaded");
                Console.ReadKey();*/
            do
            {
                
                clearScreen();
                header();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                option = Menu();
                Console.Clear();
                if (option == 1)
                {
                    mUser user = takeInputWithoutRole();
                    mCar carForViewing = new mCar();

                    if (user != null)
                    {
                        user = signIn(user, users);
                        if (user == null)
                        {
                            Console.WriteLine("Invalid User");

                        }
                        else if (user.isAdmin())
                        {
                            int value = adminMenu();
                            if (value == 1)
                            {

                                addCars(cars, path2);
                            }
                            if (value == 2)
                            {
                                headerOfViewCars();
                                carForViewing.viewAllCars(cars);
                            }
                            if (value == 3)
                            {
                                checkAvailability(carForViewing, cars);
                            }
                            if (value == 4)
                            {
                                sendForModification(carForViewing, cars);
                            }
                            if (value == 5)
                            {
                                verifyCostumer();
;                            }
                            if (value == 6)
                            {


                            }
                            if (value == 7)
                            {
                                viewUsers(users);
                            }



                        }
                        else if(user.isCostumer())
                        {
                            int value = costumerMenu();

                           
                            if (value == 1)
                            {
                                rentAcar(cars);
                            }
                            if (value == 2)
                            {

                                checkAvailability(carForViewing, cars);
                            }
                            if (value == 3)
                            {
                                // checkPrice();
                            }
                            if (value == 4)
                            {
                                headerOfViewCars();
                                carForViewing.viewAllCars(cars);
                            }
                            if (value == 5)
                            {
                                // comparePrice();
                            }
                            if (value == 6)
                            {
                                giveReview();
                            }

                        }

                    }
                }


                else if (option == 2)
                {
                    mUser user = takeInputWithRole();
                    
                    bool flag = true;
                 for(int i = 0; i <= users.Count; i++)
                    { 

                        if (user != null || user.name != users[i].name)
                        {
                           
                            i++;
                            flag = false;
                        }
                        if (user == null)
                        {
                            Console.WriteLine(">>>>>------ Invalid Input!! TRY AGAIN ------<<<<<");
                        }
                    }
                    if (flag == false)
                    {
                        storeDataInFile(path, user);
                        storeDataInList(users, user);
                        Console.WriteLine(">>>>----- USER Created Successfully :)");
                        Console.WriteLine();
                        Console.WriteLine("You Can SIgnIn");
                    }

                }
                Console.ReadKey();

            }
            while (option < 3);

        }

        static int Menu()
        {
            int option;
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Sign In ");
            Console.WriteLine("2. CREATE AN ACCOUNT");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Enter your option :");
            option = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Magenta;

            return option;

        }
        static bool readData(string path, List<mUser> users)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string name = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    mUser user = new mUser(name, password, role);
                    storeDataInList(users, user);

                }
                fileVariable.Close();
                return true;

            }
            return false;
        }
        static bool readCarData(string path2, List<mCar> cars)
        {
            if (File.Exists(path2))
            {
                StreamReader fileVariable = new StreamReader(path2);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string cName = parseData(record, 1);
                    string company = parseData(record, 2);
                    int price = int.Parse(parseData(record, 3));
                    mCar car = new mCar(cName, company, price);
                    storeCarDataInList(cars, car);

                }
                fileVariable.Close();
                return true;

            }
            return false;
        }

        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];

                }


            }
            return item;

        }
        static void storeDataInList(List<mUser> users, mUser user)
        {
            users.Add(user);
        }
        static void storeCarDataInList(List<mCar> cars, mCar car)
        {
            cars.Add(car);
        }
        static void  removeFromList(List<mCar> cars, mCar car)
        {
            cars.Remove(car);
        }

        static mUser takeInputWithoutRole()
        {
            Console.WriteLine(" :) Welcome Back !!!  (:");
            Console.WriteLine();



            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter your password: ");
            string password = Console.ReadLine();

            if (name != null && password != null)
            {
                mUser users = new mUser(name, password);
                return users;

            }
            return null;
        }
        static mUser takeInputWithRole()
        {
            Console.WriteLine("------>>>>   WellCome New User   <<<<<-----");
            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter New password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter Password Again :");
            string secondPassword = Console.ReadLine();
            Console.WriteLine("Enter Your Role: ");
            string role = Console.ReadLine();

            if (name != null && password != null && role != null && password == secondPassword)
            {
                mUser users = new mUser(name, password, role);
                return users;

            }

            return null;
        }
        static bool checkIfCarIsAvailable(mCar addCar, List<mCar> cars)
        {
            /*int i = 0;
             foreach(mCar availableCar in cars)       //availableCar = i  and search in >>cars list << 
              {
                  if ( cars[i].cName == addCar.cName)
                  {
                      return true;
                    i++;
                  }       
              }
              return false;*/

            for (int i = 0; i < cars.Count; i++)
            {
                if (cars[i].cName == addCar.cName)
                {
                    return true;
                }

            }
            return false;
        }


        static void checkAvailability(mCar addCar, List<mCar> cars)
        {
            bool check = false;
           double price = 0;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            string Name;
            Console.WriteLine("Enter the Name of Car: ");
            Name = Console.ReadLine();
            for (int i = 0; i < cars.Count; i++)
            {
                if (cars[i].cName == Name)
                {
                    check = true;
                    price = cars[i].price;
                }

            }

            if (check == true)
            {
                Console.WriteLine("Car is Available At Price of 1 Day Rent : {0}", price);
            }
            else if (check == false)
            {
                Console.WriteLine("Car is not Available");
            }

        }



        static mUser signIn(mUser user, List<mUser> users)
        {
            foreach (mUser storedUser in users)
            {
                if (user.name == storedUser.name && user.password == storedUser.password)
                {
                    return storedUser;
                }

            }
            return null;
        }
        static void storeDataInFile(string path, mUser user)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.name + "," + user.password + "," + user.role);
            file.Flush();
            file.Close();
        }
        static void storeCarDataInFile(string path2, mCar car)
        {
            StreamWriter file = new StreamWriter(path2, true);
            file.WriteLine(car.cName + "," + car.company + "," + car.price);
            file.Flush();
            file.Close();
        }
        static int adminMenu()
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(" *******************************************************************");
            Console.WriteLine(" *    _____ ____  _____ _____  _____    _____ _____ _____ _____    *");
            Console.WriteLine(" *   |  _  |    !|     |  |   |   | |  |     |   __|   | |  |  |   *");
            Console.WriteLine(" *   |     |  | || | | |  |   | | | |  | | | |   __| | | |  |  |   *");
            Console.WriteLine(" *   |__|__|____/|_|_|_|__|___|_|___|  |_|_|_|_____|_|___|_____|   *");
            Console.WriteLine(" *                                                                 *");
            Console.WriteLine(" *******************************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Add cars");
            Console.WriteLine("2. View All Cars");
            Console.WriteLine("3. Check availability ");
            Console.WriteLine("4. Modify Car");
            Console.WriteLine("5. Check Documents");
            Console.WriteLine("6. Returning A Car");
            Console.WriteLine("7. View Users");
            Console.WriteLine("8. Check Reviews");
            

            Console.WriteLine("9. EXIT");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;

            int option;
            Console.WriteLine("Select any option:");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static int costumerMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*******************************************************************");
            Console.WriteLine("*                                                                 *");
            Console.WriteLine("*      _____         _                        _____               *");
            Console.WriteLine("*     |     |___ ___| |_ _ _ _____ ___ ___   |     |___ ___ _ _   *");
            Console.WriteLine("*     |   --| . |_ -|  _| | |     | -_|  _|  | | | | -_|   | | |  *");
            Console.WriteLine("*     |_____|___|___|_| |___|_|_|_|___|_|    |_|_|_|___|_|_|___|  *");
            Console.WriteLine("*                                                                 *");
            Console.WriteLine("*******************************************************************");

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Rent A Car");
            Console.WriteLine("2. Check Availability");
            Console.WriteLine("3. Check Price");
            Console.WriteLine("4. View Car ");
            Console.WriteLine("5. Compare Price");
            Console.WriteLine("6. Give FeedBack");
            Console.WriteLine("7. EXIT");
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Select any option:");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
        static void addCars(List<mCar> cars, string path2)
        {
            headerOfAddCars();
            Console.WriteLine("Enter the Name of Car: ");
            string cName = Console.ReadLine();
            Console.WriteLine("Enter the Name of Company: ");
            string company = Console.ReadLine();
            Console.WriteLine("Enter the Price for 1 Day Rent : ");
            int price;
            price = int.Parse(Console.ReadLine());

            //     >>>>> object of the Car
            mCar addCar = new mCar(cName, company, price);

            Console.ForegroundColor = ConsoleColor.Red;

            bool check = false;
            check = checkIfCarIsAvailable(addCar, cars);

            if (check == true)
            {
                Console.WriteLine("((------Car Already Available------))");
            }

            if (check == false)
            {
                 storeCarDataInList(cars,addCar );
               /* int i = 0;
                foreach (mCar car in cars)
                {

                    Console.WriteLine("The entered Car :{0}\t The price : {1} \t The Company : {2}" ,cars[i].cName,cars[i].price,cars[i].company );
                        i++;
                }*/
                storeCarDataInFile(path2, addCar);
                Console.WriteLine(" Congratulations !!!   Car Entered Successfully");
            }



        }
        static void headerOfAddCars()
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*                                                       *  ");
            Console.WriteLine("*        _____ ____  ____     _____ _____ _____ _____   *  ");
            Console.WriteLine("*       |  _  |    !|    !   |     |  _  | __  |   __|  *  ");
            Console.WriteLine("*       |     |  |  |  |  |  |   --|     |    -|__   |  *  ");
            Console.WriteLine("*       |__|__|____/|____/   |_____|__|__|__|__|_____|  *  ");
            Console.WriteLine("*                                                       *  ");
            Console.WriteLine("*********************************************************");

            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        static void viewUsers(List<mUser> users)
        {
            int j = 1;
            for (int i = 0; i < users.Count; i++)
            {
                Console.WriteLine("{0} Name>> {1}\t\t Role>> {2} ", j, users[i].name, users[i].role);
                j++;
            }
        }

        static void clearScreen()
        {
            Console.WriteLine("Press any Key to Continue...");
            Console.ReadKey();
            Console.Clear();
        }
        static void sendForModification( mCar carForViewing, List <mCar> cars)
        {
            
            carForViewing.viewAllCars(cars);
            Console.WriteLine("Which Car you want to send for modification : ");
            string car = Console.ReadLine();

            mCar s = new mCar(car);
            // bool flag = checkIfCarIsAvailable(s, cars);
            bool flag = false;
            foreach (mCar search in cars)
            {
                if (cars.Contains(search))
                {
                    removeFromList(cars, carForViewing);
                    Console.WriteLine("The modification Price will be : {0} ", (15 / 100) * s.price);
                    flag = true;

                }
            }
            if(flag == false)
            {
                Console.Write("this is false value: ");
            }

          
        }
         
        static Review checkReviews()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(" >>>>-----  Costumer Reviews-----<<<<<< ");
            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine("User's Name :{0}\t\t\tReview:{1} ");
            return null;
        }

        static  void rentAcar(List<mCar> cars)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("******************************************************************" );
            Console.WriteLine("*                                                                *" );
            Console.WriteLine("*     _____ _____ _____ _____      _____    _____ _____ _____    *" );
            Console.WriteLine("*    | __  |   __|   | |_   _|    |  _  |  |     |  _  | __  |   *" );
            Console.WriteLine("*    |    -|   __| | | | | |      |     |  |   --|     |    -|   *" );
            Console.WriteLine("*    |__|__|_____|_|___| |_|      |__|__|  |_____|__|__|__|__|   *" );
            Console.WriteLine("*                                                                *" );
            Console.WriteLine("******************************************************************" );
            Console.ForegroundColor = ConsoleColor.Magenta;

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
           
            mCar s = checkAvailabilityOfCar(cars);
            if (s != null)
            {


                Console.WriteLine("For How Many Days you Want to take it : ");
                int ndays = int.Parse(Console.ReadLine());
                Console.WriteLine(" Entered Car is :{0}\tPrice for {1} DAY Rent is:{2}  ", s.cName, ndays, (ndays * s.price));
                removeFromList(cars, s);
            }
            if(s== null)
            {
                Console.WriteLine("((((------- Invalid Input!! ------))))");
                
            }
        }
        static mCar checkAvailabilityOfCar(List<mCar> cars)
        {



            double price = 0;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
           

            Console.WriteLine("Enter the Name of Car: ");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter the Company of Car : ");
            string company = Console.ReadLine();
            for (int i = 0; i < cars.Count; i++)
            {
                if (cars[i].cName == Name && cars[i].company == company)
                {

                    price = cars[i].price;
                    mCar newCar = new  mCar (Name,company, price);
                    return newCar;

                }
            }
            return null;
        }

        static Review giveReview()
        {
            

            List<Review> reviews = new List<Review>();
            Console.WriteLine("Enter Car You want to give a REVIEW to");
            string carForReview = Console.ReadLine();
            Console.WriteLine("Give Stars : ");
            int stars = int.Parse(Console.ReadLine());

            Review r = new Review(carForReview, stars);

            r= r.printReviews(reviews,r);

            addReviewsInList(r, reviews);
          

            return null;
        }
        static void addReviewsInList(Review r, List<Review> reviews)
        {
            reviews.Add(r);

         /*   int i = 0;
            foreach(Review s in reviews)
            {
                Console.WriteLine("THe Stars :{0}\t For :{1} ",reviews[i].stars,reviews[i].carForReview);
                i++;
                return r;
            }*/
            
        }
      
        static void header()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("********************************************" );
            Console.WriteLine("*                                          *  ");
            Console.WriteLine("*   _____              _____         _     *  " );
            Console.WriteLine("*  |     |  ___ ___   | __  |___ ___| |_   *  " );
            Console.WriteLine("*  |       | .'|  _|  |    -| -_|   |  _|  *  " );
            Console.WriteLine("*  |_____| |__,|_|    |__|__|___|_|_|_|    *  " );
            Console.WriteLine("*                                          *  " );
            Console.WriteLine("********************************************" );
        }
        static void headerOfViewCars()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*                                                       *");
            Console.WriteLine("*       _____ _              _____ _____ _____ _____    *" );
            Console.WriteLine("*      |  |  |_|___ _ _ _   |     |  _  | __  |   __|   *" );
            Console.WriteLine("*      |  |  | | -_| | | |  |   --|     |    -|__   |   *" );
            Console.WriteLine("*       !___/|_|___|_____|  |_____|__|__|__|__|_____|   *" );
            Console.WriteLine("*                                                       *" );
            Console.WriteLine("*********************************************************" );
            Console.ForegroundColor = ConsoleColor.Magenta;
        }
        static void verifyCostumer()
        {
            
            Console.WriteLine("******************CHECK DOCUMENTS********************");

            char age;
            char license;
            Console.WriteLine("Is the COSTUMER above 18??   (y/n)") ;
            age = char.Parse(Console.ReadLine());
                
            Console.WriteLine("Does the COSTUMER possess a License??    (y/n)");
            license = char.Parse(Console.ReadLine());
            if ((age == 'y' || age == 'Y') && (license == 'y' || license == 'Y'))
            {
                // system("Color 0A");
                Console.WriteLine("______________________" );
                Console.WriteLine("COSTUMER is ELEGIBLE !!");
                Console.WriteLine("______________________" );
                Console.WriteLine("Press Any Key To Continue: ");
                Console.WriteLine();
                
               
            }
            else
            {
                // system("Color E4");
                Console.WriteLine("___________________________" );
                Console.WriteLine("COSTUMER IS NOT ELIGIBLE !!" );
                Console.WriteLine("___________________________" );

                Console.WriteLine("Press Any Key To Continue: ");
                     Console.WriteLine();
              
            }
        }
    }
}

