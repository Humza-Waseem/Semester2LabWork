﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;

namespace ConsoleApp1
{
    class Program
    {
        static List<Student> studentList = new List<Student>();
        static List<DegreeProgram> programList = new List<DegreeProgram>();


        static void Main(string[] args)
        {
            // --------task 1--------
            /*Student s1 = new Student("Ahmad", 15, 120);
            Student s2 = new Student("Hassan", 11, 115);
            Student s3 = new Student("Ali", 12, 159);
            List<Student> studentList = new List<Student>() { s1, s2, s3 };
            List<Student> sortedList = studentList.OrderBy(o => o.rollN).ToList();
            Console.WriteLine("Name \t Roll No \t EcatMarks ");
            foreach (Student s in sortedList)
            {
                Console.WriteLine("{0} \t {1} \t \t  {2} ", s.name, s.rollN, s.ecatMarks);

            }
            Console.Read();*/
            int option;
            do
            {
                option = Menu();
                clearScreen();
                if (option == 1)
                {
                    if (programList.Count > 0)
                    {
                        Student s = takeInputForStudent();
                        addIntoStudentList(s);
                    }
                }
                else if (option == 2)
                {
                    DegreeProgram d = takeInputForDegree();
                    addIntoDegreeList(d);
                }

                else if (option == 3)
                {
                    List<Student> sortedStudentList = new List<Student>();
                    sortedStudentList = sortStudentByMerit();
                    giveAdmission(sortedStudentList);
                    printStudents();

                }
                else if (option == 4)
                {
                    viewRegisteredStudents();
                }
                else if (option == 5)
                {
                    {
                        string degName;
                        Console.Write("Enter Degree Name : ");
                        degName = Console.ReadLine();
                        viewStudentInDegree(degName);

                    }
                }
                else if (option == 6)
                {
                    Console.Write("Enter the student Name : ");
                    string name = Console.ReadLine();
                    Student s = StudentPresent(name);
                    if (s != null)
                    {
                        viewSUbject(s);
                        registerSubjects(s);
                    }
                }
                else if (option == 7)
                {
                    calculateFeeForAll();

                }
                clearScreen();
            }
            while (option != 8);
            Console.ReadKey();

        }
       
       
       static void clearScreen()
        {
            Console.WriteLine("Press any key to Continue..");
            Console.ReadKey();
            Console.Clear();
        }
       
        static void viewStudentInDegree(string degName)
        {
            Console.WriteLine("Name\tFsC\tEcat\tAge");
            foreach ( Student s in studentList)
            {
                if(s.regSubject!=null )
                {
                    
                        if(degName == s.regDegree.degreeName)
                        {
                            Console.WriteLine(s.name + "\t " + s.fsc + "\t" + s.ecat + "\t" + s.age);

                        }
                    
                }
            }
        }
        static void viewRegisteredStudents()
        {
            Console.WriteLine("Name\tFSC\tEcat\tAge");
            foreach (Student s in studentList)
            {
                if(s.regDegree != null)
                {
                    Console.WriteLine(s.name + "\t" + s.fsc + "\t" + s.ecat + "\t" + s.age);

                }
            }
        }
        static void addIntoDegreeList(DegreeProgram d)
        {
            programList.Add(d);
        }
        static DegreeProgram takeInputForDegree()
        {
            string degreeName;
            float degreeDuration;
            int seats;
            Console.Write("Enter Degree Name : ");
            degreeName = Console.ReadLine();
            Console.Write("Enter Degree Duration : ");
            degreeDuration = float.Parse(Console.ReadLine());
            Console.Write("Enter Seats for Degree : ");
            seats = int.Parse(Console.ReadLine());

            DegreeProgram degProg = new DegreeProgram(degreeName, degreeDuration, seats);
            Console.Write("Enter How many Subjects to Enter : ");
            int count =0;
      
            for (int x = 0; x <count; x++)
            {
                degProg.AddSubject(takeInputForSubject());
            }
            return degProg;

        }
        static Subject takeInputForSubject()
        {
            string code;
            string type;
            int creditHours;
            int subjectFees;
            Console.Write("Enter subject COde : ");
            code = Console.ReadLine();
            Console.Write("Enter Subject Type : ");
            type = Console.ReadLine();
            Console.Write("Enter subject CreditHours : ");
            creditHours = Console.Read();
            Console.Write("Enter Subject Fees : ");
            subjectFees = Console.Read();
            Subject sub = new Subject(code, type, creditHours, subjectFees);
            return sub;
            

        }
        static void addIntoStudentList(Student s)
        {
            addIntoStudentList().Add(s);
        }
        static Student takeInputForStudent()
        {
            string name;
            int age;
            double fsc;
            double ecat;
            List<DegreeProgram> preferences = new List<DegreeProgram>();
            Console.WriteLine("Enter Student Name :");
            name = Console.ReadLine();

            Console.Write("Enter Student AGe :");
            age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Student FSC Marks  :");
            fsc = double.Parse(Console.ReadLine());
            Console.Write("Enter Student Ecat Marks  :");
            ecat = double.Parse(Console.ReadLine());
            Console.WriteLine("Available Degree Programs :");
            viewDegreePrograms();
            Console.Write("Enter How many preferences to Enter : ");
            int count = int.Parse(Console.ReadLine());
            for(int x = 0; x< count; x++)
            {
                string degName = Console.ReadLine();
                bool flag = false;
                foreach ( DegreeProgram dp in programList)
                {
                    if(degName == dp.degreeName && !(preferences.Contains(dp)))
                    {
                        preferences.Add(dp);
                        flag = true;
                    }

                }
                if(flag== false)
                {
                    Console.WriteLine("Enter Valid Degree Program Name");
                    x--;
                }

            }
            Student s = new Student(name, age, fsc, ecat, preferences);
            return s;
        }
      
        static void viewDegreePrograms()
        {
            foreach(DegreeProgram dp in ProgramList)
            {
                Console.WriteLine(dp.degreeDuration);

            }
        }
        static void header()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("           UAMS           ");
            Console.WriteLine("**************************");

        }
        static void viewSUbject(Student s)
        {
            if(s.regDegree != null)
            {
                Console.WriteLine("Sub Code\tSub Type ");
                foreach (Subject sub in s.regDegree.subjects)
                {
                    Console.WriteLine(sub.code + "\t\t" + sub.type);
                }
            }
        }
        static int Menu()
        {
            header();
            int option;
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Add Degree Program");
            Console.WriteLine("3. Generate Merit");
            Console.WriteLine("4. View Registered Studetns");
            Console.WriteLine("5. View Student of a specific Program");
            Console.WriteLine("6. Register Subjects for a Specific Student");
            Console.WriteLine("7. Calculate Fees for all Registerd Students ");
            Console.WriteLine("8. Exit");
            Console.WriteLine("Entre Your Option :");
            option = int.Parse(Console.ReadLine());
            return option;
        }

    }
    

}
