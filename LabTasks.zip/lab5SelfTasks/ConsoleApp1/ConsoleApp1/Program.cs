﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            do
            {
                int returnedOption = firstMenu();
                if (returnedOption == 1)
                {

                }
                if (returnedOption == 2)
                {

                }
                if (returnedOption == 3)
                {

                }
                if (returnedOption == 4)
                {

                }
                if (returnedOption == 5)
                {

                }
                if (returnedOption == 6)
                {

                }

                if (returnedOption == 7)
                {

                }
                if (returnedOption == 8)
                {

                }
                if (returnedOption == 9)
                {

                }

            }
            while (true);
        }

         static  int firstMenu()
        {
            Console.WriteLine("1. Make a Line");
            Console.WriteLine("2.Update the begin point");
            Console.WriteLine("3.Update the end point");
            Console.WriteLine("4.Show the begin Point");
            Console.WriteLine("5.Show the end point");
            Console.WriteLine("6.Get the Length of the line");
            Console.WriteLine("7.Get the Gradient of the Line");
            Console.WriteLine("8.Find the distance of begin point from zero coordinates");
            Console.WriteLine("9.Find the distance of end point from zero coordinates");
            Console.WriteLine("10.Exit");
            int option;
            Console.WriteLine("Enter Your Option : ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
    }
}
