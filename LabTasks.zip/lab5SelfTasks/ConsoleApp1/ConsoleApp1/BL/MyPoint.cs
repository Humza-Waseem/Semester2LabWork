﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL
{
    class MyPoint
    {
        public int x;
        public int y;

        public MyPoint()
        {

        }
        public MyPoint(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public int getX()
        {
            Console.WriteLine("Enter the X point : ");
            x = int.Parse(Console.ReadLine());

            return x;
        }
        public int getY()
        {
            Console.WriteLine("Enter the Y point : ");
            y = int.Parse(Console.ReadLine());

            return y;
        }
        public void setXY(int x, int y)
        {
            Console.SetCursorPosition( x, y);

        }
    }
}
