﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            //   ----------- >>>>>> Default Constructor SELF ASSESMENT 1 and 2   <<<<<< -----------

            /* student s1 = new student();
               Console.WriteLine("First nAME::{0} ",s1.sname);
               Console.WriteLine("The float value of matric marks is : {0}", s1.matricMarks);
               Console.WriteLine("The float value of ecat marks is : {0}", s1.ecat);
               Console.WriteLine("The float value of matric marks is : {0}", s1.fsc);
               Console.WriteLine("The float value of matric marks is : {0}", s1.aggregate );

               student s2 = new student();
               Console.WriteLine("Second nAME::{0} ",s2.sname);
               Console.WriteLine("The float value of matric marks is : {0}", s2.matricMarks);
             Console.WriteLine("The float value of ecat marks is : {0}", s2.ecat);
               Console.WriteLine("The float value of matric marks is : {0}", s2.fsc);
               Console.WriteLine("The float value of matric marks is : {0}", s2.aggregate );

               student s3 = new student();
               Console.WriteLine("Third nAME::{0} ", s3.sname);

               Console.WriteLine("The float value of matric marks is : {0}", s3.matricMarks);
             Console.WriteLine("The float value of ecat marks is : {0}", s2.ecat);
             Console.WriteLine("The float value of matric marks is : {0}", s2.fsc);
             Console.WriteLine("The float value of matric marks is : {0}", s2.aggregate );
             */


            //     ------>>> parametrized constructors  SELF ASSESEMENT 1 & 2 <<<------


            /* Console.WriteLine("Data of student 1");
             student s1 = new student(200,"Hamza ",1063.5F,991.5F,80.0123F);
             Console.WriteLine("The ecat is : " + s1.ecat);
             Console.WriteLine(" MY Name is : " + s1.sname);
             Console.WriteLine("MY Matric marks are:  " + s1.matricMarks);
             Console.WriteLine("MY Inter marks are:  " + s1.fsc);
             Console.WriteLine("MY aggregate is:  " + s1.aggregate);
             Console.WriteLine();



             Console.WriteLine("Data of student 2");
             Console.WriteLine();
             student s2 = new student(100, "Mehar", 1002.5F, 1001.5F, 79.0123F);
             Console.WriteLine("The ecat marks are: " + s2.ecat);
             Console.WriteLine("MY name is : " + s2.sname);
             Console.WriteLine("MY Matric marks are:  " + s2.matricMarks);
             Console.WriteLine("MY Inter marks are:  " + s2.fsc);
             Console.WriteLine("MY aggregate is:  " + s2.aggregate);
             Console.WriteLine();


             Console.WriteLine("Data of student 3")
             Console.WriteLine();
             student s3 = new student(344, "bILAL", 990.5F, 889F, 75.9897F);
             Console.WriteLine("The ecat marks are: " + s3.ecat);
             Console.WriteLine("MY name is : " + s3.sname);
             Console.WriteLine("MY Matric marks are:  " + s3.matricMarks);
             Console.WriteLine("MY Inter marks are:  " + s3.fsc);
             Console.WriteLine("MY aggregate is:  " + s3.aggregate);
            */


            //   ---------- >>>>> COPY CONSTRUCTOR  <<<<<-------------

            /*    student s1 = new student();

                s1.sname = "Hamza";
                s1.aggregate = 88.91F;
                s1.fsc = 991;
                s1.matricMarks = 1063.5F;
                s1.ecat = 157.756F;

                student s2 = new student(s1);
                Console.WriteLine(s1.sname);
                Console.WriteLine(s2.sname);
                Console.WriteLine(s1.aggregate);
                Console.WriteLine(s2.aggregate);
                Console.WriteLine(s1.fsc);
                Console.WriteLine(s2.fsc);
                Console.WriteLine(s1.matricMarks);
                Console.WriteLine(s2.matricMarks);
                Console.WriteLine(s1.ecat);
                Console.WriteLine(s2.ecat);
            */

            //  ----->>>> FOR EACH LOOP <<<<-----------

            /*    List<string> Cars = new List<string>() { "ferrari","santro","supra","GTR" };


                foreach(var car in Cars)
                {
                    Console.WriteLine(car);


                }
            */


            /*
            // default constructor
            clockType empty_time = new clockType();
            Console.Write("Empty time:");
            empty_time.printTime();

            // Parametrized contructor ( one parameter
            clockType hour_time = new clockType(8);
            Console.WriteLine("Hour Time:");
            hour_time.printTime();

            //Parametrized contructor (two parameters)
            clockType minute_time = new clockType(8, 10);
            Console.Write("Minute Time:");
            minute_time.printTime();

            // Parametrized constructor ( three parameters)
            clockType full_time = new clockType(8, 10, 10);
            Console.WriteLine("Full Time : ");
            full_time.printTime();


            // increment second
            full_time.incrementSecond();
            Console.Write("Full time ( INCrement second: ");
            full_timetime.printTime();

            // increment hours
            full_time.incrementhours();
            Console.Write("full time(increment hours": );
            full_time.printTime();

            // increment minutes
            full_time.incrementminutes();
            Console.Write("Full time (INcrement MINutes ) :");
            full_time.printTime();

            //check if equal
            bool flag = full_time.isEqual(9, 11, 11);
            Console.WriteLine("Flag : " + flag);


            // check if equal with object
            clockType cmp = new clockType(10, 12, 1);
            flag = full_time.isEqual(cmp);
            Console.WriteLine("OBject Flag : " + flag);
        }

            public void incrementSeconds()
            {
                Sec++;
            }
            public void incrementMinutes()
            {
                mins++;
            }
            public void incrementHours()
            {
                hours++;
            }
            public void printTime()
            {
                Console.WriteLine(hours + " " + mins + " " + Seconds);
            }
            public bool isEqual(int h, int m, int s)
            {
                if (hours == h && mins == m && sec == s)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }
            public bool isEqual(clockType temp)
            {
                if (hours == temp.hours && mins == temp.minutes && sec == temp.sec)
                {
                    return true;
                }
                else
                {
                    return false;
                }*/

            // List<int> products = new List<int>();

            MissClient s1 = new MissClient();
            MissClient[] arr = new MissClient[10];

            int count = 0;
            int choice;


            do
            {
                Console.Clear();
                choice = mainMenu();
                if (choice == 1)
                {
                    arr[count] = addProducts(s1);
                    count++;
                }
                else if (choice == 2)
                {
                    viewProducts(arr, count);
                }
                else if (choice == 3)
                {
                    Console.Clear();
                    float highest;

                    highest = highestUnitPrice(arr, count);
                    Console.WriteLine("The highest value of price is : " + highest);
                    Console.Read();
                }
                else if (choice == 4)
                {
                    Console.Clear();
                    float tax = 0;

                    tax = salesTax(arr,count);
                    Console.WriteLine("The sales Tax is : "+tax);
                    Console.WriteLine("Price entered is : "+ s1.price);
                    Console.ReadKey();

                    
                }
                else if (choice == 5)
                {

                }
            }
            while (choice != 6);
            Console.ReadKey();



        }

        static int mainMenu()
        {

            int option = 0;
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Add Products ");
            Console.WriteLine("2. View All Products");
            Console.WriteLine("3. Find Product with the highest unit price");
            Console.WriteLine("4. Sales Tax");
            Console.WriteLine("5. PRoducts to be Ordered");
            Console.WriteLine("6. EXIT");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ENTer your Choice: ");
            option = int.Parse(Console.ReadLine());
            return option;

        }
        static MissClient addProducts(MissClient s1)
        {

            Console.Clear();

          //  MissClient s1 = new MissClient();

            Console.ForegroundColor = ConsoleColor.DarkYellow;

            Console.WriteLine("Enter the name of Product ");
            s1.nProduct = Console.ReadLine();

            Console.WriteLine("Enter the Price ");
            s1.price = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the CATEGORY of Product ");
            s1.category = Console.ReadLine();

            Console.WriteLine("Enter the Stock  Quantity ");
            s1.stock = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Minimum Stock Quantity ");
            s1.minStock = int.Parse(Console.ReadLine());

            return s1;


        }
        static void viewProducts(MissClient[] s, int count)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;

            for (int i = 0; i < count; i++)

            {
                Console.WriteLine("  \nName of Product:{0} \nPrice:{1}  \nCategory:{2}\nQuantity :{3}\nMinimum Stock Quantity :{4}", s[i].nProduct, s[i].price, s[i].category, s[i].stock, s[i].minStock);
            }
            Console.WriteLine("Press any Key to COntinue...");
            Console.ReadKey();
        }
        static float highestUnitPrice(MissClient[] s, int count)
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Gray;

            int j = 0;
            float highest = s[j].price;
            for (int i = 0; i <= count; i++)
            {
                if (highest <= s[i].price)
                {
                    highest = s[j].price;


                }
                else
                {
                    continue;

                }
            }
            return highest;

        }
        static float salesTax(MissClient [] s, int count)
            
            {

            float saleTax = 0;
            float new1 = 0;
            for (int i = 0; i < count; i++)
            {
               if(s[i].category == "Grocery" || s[i].category == "grocery" || s[i].category == "GROCERY")
                {

                    new1 = s[i].price *10/100F;
                    saleTax = saleTax + new1;
                  

                }

                if (s[i].category == "Fruit" || s[i].category == "fruit" || s[i].category == "FRUIT")
                {

                    new1 = new1 +(s[i].price * 5/100);
                    saleTax = saleTax + new1;

                }
                else
                {
                    new1 = new1 + (s[i].price / 15);
                    saleTax = saleTax + new1;
                }   
            }
            return saleTax;
            }
            

        
    }
}