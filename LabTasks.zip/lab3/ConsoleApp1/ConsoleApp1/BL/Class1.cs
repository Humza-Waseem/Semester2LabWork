﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL
{
    class MissClient
    {

        public string nProduct;
        public  float price;
        public string category;
        public int stock;
        public int minStock;
      
      /*  public float calculateTax()
        {
            float saleTax = 0;
            float new1 = 0;
            
                if (category == "Grocery" ||category == "grocery" || category == "GROCERY")
                {

                    new1 = price * 10 / 100F;
                    saleTax = saleTax + new1;

                return saleTax;

                }

                if (category == "Fruit" || category == "fruit" || category == "FRUIT")
                {

                    new1 = new1 + (price * 5/100F);
                    saleTax = saleTax + new1;
                return saleTax;
            }
                else
                {
                    new1 = new1 + (price / 15);
                    saleTax = saleTax + new1;
                return saleTax;
            }
            
            return saleTax;
        }*/

    }
}
