using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.BL;
using System.IO;
using System.ComponentModel.Design;
using System.Security.Cryptography.X509Certificates;
using ConsoleApp1.BL.BL;

namespace ConsoleApp1
{
    internal class Program
    {
       

        static void Main(string[] args)
        {
            //  >>>>  List of name USERS  and DataType User that is a class 
            List<mUser> users = new List<mUser>();

            //   >>>>>>   List of CARS 
            List<mCar> cars = new List<mCar>();

            // file for user Data
            string path = "textfile.txt";

            // file for CAR DATA
            string path2 = "E:\\OOPlab\\NewPd4\\ConsoleApp1\\ConsoleApp1\\bin\\Debug\\carsData.txt";



            int option;

            //reading the file in which our data is saved
            bool check = readData( path,users);

            //fuction to read Car DATA B4 fuction exection
            readCarData( path2,cars);


            if (check)
            {
                Console.WriteLine("Data Loaded Successfully");

            }
            else
                Console.WriteLine("Data not Loaded");
            Console.ReadKey();
            do
            {

                Console.Clear();
                option = Menu();
                Console.Clear();
                if (option == 1)
                {
                    mUser user = takeInputWithoutRole();
                    mCar carForViewing = new mCar();
                    if (user != null)
                    {
                        user = signIn(user, users);
                        if (user == null)
                        {
                            Console.WriteLine("Invalid User");

                        }
                        else if (user.isAdmin())
                        {
                           int value = adminMenu();
                           if(value == 1)
                            {
                                
                                addCars(cars,path2);
                            }
                            if (value == 2)
                            {
                                carForViewing.viewAllCars(cars);
                            }
                            if (value == 3)
                            {
                                checkAvailability(carForViewing,cars);
                            }
                            if (value == 4)
                            {
                                sendCarForModification(carForViewing, cars);
                            }
                            if (value == 5)
                            {

                            }
                            if (value == 6)
                            {

                                    
                            } 
                            if (value == 7)
                            {
                                viewUsers(users);
                             }



                    }
                        else 
                        {
                            costumerMenu();
                        }
                    }
                }


                else if (option == 2)
                {
                    mUser user = takeInputWithRole();
                    if (user != null)
                    {
                        storeDataInFile(path, user);
                        storeDataInList(users, user);

                    }

                }
                Console.ReadKey();

            }
            while (option < 3);

        }

        static int Menu()
        {
            int option;
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. GET STARTED ");
            Console.WriteLine("2. CREATE AN ACCOUNT");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Enter your option :");
            option = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Magenta;

            return option;

        }
        static bool readData(string path, List<mUser> users)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string name = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    mUser user = new mUser(name, password, role);
                    storeDataInList(users, user);

                }
                fileVariable.Close();
                return true;

            }
            return false;
        }
        static bool readCarData(string path2, List<mCar> cars)
        {
            if (File.Exists(path2))
            {
                StreamReader fileVariable = new StreamReader(path2);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string cName = parseData(record, 1);
                    string company = parseData(record, 2);
                    int price = int.Parse(parseData(record, 3));
                    mCar car = new mCar(cName, company, price);
                    storeCarDataInList(cars, car);

                }
                fileVariable.Close();
                return true;

            }
            return false;
        }

        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];

                }


            }
            return item;

        }
        static void storeDataInList(List<mUser> users, mUser user)
        {
            users.Add(user);
        }
        static void storeCarDataInList(List<mCar> cars, mCar car)
        {
            cars.Add(car);
        }


        static mUser takeInputWithoutRole()
        {
            Console.WriteLine(" :) Welcome Back !!!  (:");



                       Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter your password: ");
            string password = Console.ReadLine();

            if (name != null && password != null)
            {
                mUser users = new mUser(name, password);
                return users;

            }
            return null;
        }
        static mUser takeInputWithRole()
        {
            Console.WriteLine("------>>>>   WellCome New User   <<<<<-----");
            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();

            Console.WriteLine("Enter your password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter Your Role: ");
            string role = Console.ReadLine();

            if (name != null && password != null && role != null)
            {
                mUser users = new mUser(name, password, role);
                return users;

            }
            return null;
        }
        static bool checkIfCarIsAvailable(mCar addCar, List<mCar> cars)
        {
            /*  foreach(int i in cars)       //availableCar = i  and search in >>cars list << 
              {
                  if ( cars[i].cName == addCar.cName)
                  {
                      return true;

                  }       
              }
              return false;*/

            for (int i = 0; i < cars.Count; i++)
            {
                if (cars[i].cName == addCar.cName)
                {
                    return true;
                }

            }
            return false;
          
        }
        static mCar ReturnCarForModification(mCar addCar, List<mCar> cars)
        {
            for (int i = 0; i < cars.Count; i++)
            {
                if (cars[i].cName == addCar.cName)
                {
                    return cars[i];
                }

            }
            return null;
        }
            

           static void checkAvailability(mCar addCar,List<mCar> cars)
            {
            bool check = false;
            int price = 0;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            string Name;
              Console.WriteLine("Enter the Name of Car: ");
              Name = Console.ReadLine();
                for (int i = 0; i < cars.Count; i++)
                {
                    if (cars[i].cName == Name)
                    {
                      check = true;
                      price = cars[i].price;
                    }
                
                }

                if(check == true)
                {
                Console.WriteLine("Car is Available At Price of 1 Day Rent : {0}", price);
                }
                else if (check == false)
                {
                Console.WriteLine("Car is not Available");
                }
           
        }

        

        static mUser signIn(mUser user, List<mUser> users)
        {
            foreach (mUser storedUser in users)
            {
                if (user.name == storedUser.name && user.password == storedUser.password)
                {
                    return storedUser;
                }

            }
            return null;
        }
        static void storeDataInFile(string path, mUser user)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.name + "," + user.password + "," + user.role);
            file.Flush();
            file.Close();
        }
        static void storeCarDataInFile(string path2, mCar car)
        {
            StreamWriter file = new StreamWriter(path2, true);
            file.WriteLine(car.cName + "," + car.company + "," + car.price);
            file.Flush();
            file.Close();
        }
        static int adminMenu()
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(" *******************************************************************");
            Console.WriteLine(" *    _____ ____  _____ _____  _____    _____ _____ _____ _____    *");
            Console.WriteLine(" *   |  _  |    !|     |  |   |   | |  |     |   __|   | |  |  |   *");
            Console.WriteLine(" *   |     |  | || | | |  |   | | | |  | | | |   __| | | |  |  |   *");
            Console.WriteLine(" *   |__|__|____/|_|_|_|__|___|_|___|  |_|_|_|_____|_|___|_____|   *");
            Console.WriteLine(" *                                                                 *");
            Console.WriteLine(" *******************************************************************");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Add cars");
            Console.WriteLine("2. View All Cars");
            Console.WriteLine("3. Check availability ");
            Console.WriteLine("4. Modify Car");
            Console.WriteLine("5. Check Documents");
            Console.WriteLine("6. Returning A Car");
            Console.WriteLine("7. View Users");
            Console.WriteLine("8. Check Reviews");
            Console.WriteLine("9. EXIT");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;

            int option;
            Console.WriteLine("Select any option:");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static int costumerMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*******************************************************************");
            Console.WriteLine("*                                                                 *");
            Console.WriteLine("*      _____         _                        _____               *");
            Console.WriteLine("*     |     |___ ___| |_ _ _ _____ ___ ___   |     |___ ___ _ _   *");
            Console.WriteLine("*     |   --| . |_ -|  _| | |     | -_|  _|  | | | | -_|   | | |  *");
            Console.WriteLine("*     |_____|___|___|_| |___|_|_|_|___|_|    |_|_|_|___|_|_|___|  *");
            Console.WriteLine("*                                                                 *");
            Console.WriteLine("*******************************************************************");

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("1. Rent A Car");
            Console.WriteLine("2. Check Availability");
            Console.WriteLine("3. Check Price");
            Console.WriteLine("4. View Car ");
            Console.WriteLine("5. Compare Price");
            Console.WriteLine("6. Give FeedBack");
            Console.WriteLine("7. EXIT");
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Select any option:");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
        static void addCars( List<mCar> cars, string path2)
        {

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*                                                       *  ");
            Console.WriteLine("*        _____ ____  ____     _____ _____ _____ _____   *  ");
            Console.WriteLine("*       |  _  |    !|    !   |     |  _  | __  |   __|  *  ");
            Console.WriteLine("*       |     |  |  |  |  |  |   --|     |    -|__   |  *  ");
            Console.WriteLine("*       |__|__|____/|____/   |_____|__|__|__|__|_____|  *  ");
            Console.WriteLine("*                                                       *  ");
            Console.WriteLine("*********************************************************");

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Enter the Name of Car: ");
            string cName = Console.ReadLine();
            Console.WriteLine("Enter the Name of Company: ");
            string company = Console.ReadLine();
            Console.WriteLine("Enter the Price for 1 Day: ");
            int price;
            price = int.Parse(Console.ReadLine());

            //     >>>>> object of the Car
            mCar addCar = new mCar(cName, company, price);

            Console.ForegroundColor = ConsoleColor.Red;
            
            storeCarDataInList(cars,addCar);
            bool check = false;
            check = checkIfCarIsAvailable( addCar,cars);
            

            if (check ==true)
            {
                Console.WriteLine("Car Already Available");
            }

            if (check == false)
            {
                // storeCarDataInList(car1, );

                storeCarDataInFile(path2, addCar);
                Console.WriteLine("Car Entered Successfully");
            }



        }
        static void viewUsers(List<mUser> users)
        {
            int j = 1;
            for (int i = 0; i <users.Count; i++)
            {
                Console.WriteLine("{0} Name>> {1}\t\t Role>> {2} ",j,users[i].name,users[i].role);
                j++;
            }
        }
        
        static void sendCarForModification(mCar addCar, List<mCar> cars)
        {
            Console.WriteLine("Enter the Car for Modification : ");
            bool check =checkIfCarIsAvailable(addCar, cars);
            if(check == true)
            {
               // mCar car;
               // car = ReturnCarForModification(addCar, cars);
               // cars.Remove(car);
            }
            else

            {
                Console.WriteLine("Car is Not Available. Try using Capital letters!!");
            }

        }
        
    }
}

