﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.BL.BL
{
    internal class mCar
    {
        public string cName;
        public string company;
        public int price;
        public mCar(string cName, string company, int price)
        {
            this.cName = cName;
            this.company = company;
            this.price = price;

        }
        public mCar()
        {

        
        }

        public void viewAllCars( List<mCar> cars)
            {

            Console.Clear();
              Console.ForegroundColor = ConsoleColor.Magenta;
                for (int i = 0; i < cars.Count; i++)
                {
                    
                        Console.WriteLine("<<CAR>>:{0}\t\t<<COMPANY>> :{1}\t\t<<PRICE>> :{2} ", cars[i].cName, cars[i].company, cars[i].price );
                       

                }
            Console.ForegroundColor = ConsoleColor.Yellow;


        }
       
    }
}
